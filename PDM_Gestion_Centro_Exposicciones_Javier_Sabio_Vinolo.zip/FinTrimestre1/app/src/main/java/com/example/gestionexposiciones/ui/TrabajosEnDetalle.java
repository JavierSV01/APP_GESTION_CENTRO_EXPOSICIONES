package com.example.gestionexposiciones.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.gestionexposiciones.R;

public class TrabajosEnDetalle extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trabajos_en_detalle);

        TextView txNombre = findViewById(R.id.txNombre);
        TextView txDescripcion = findViewById(R.id.txDescripcion);
        TextView txPeso = findViewById(R.id.txPeso);
        TextView txTamaño = findViewById(R.id.txTamaño);
        TextView txDni = findViewById(R.id.txDni);
        TextView txFoto = findViewById(R.id.txRutaFoto);
        ImageView img = findViewById(R.id.imagenTrabajo);

        Bundle datos = this.getIntent().getExtras();
        txNombre.setText(datos.getString("nombreTrabajo"));
        txDescripcion.setText(datos.getString("descripcion"));
        txPeso.setText(datos.getString("peso"));
        txTamaño.setText(datos.getString("tamaño"));
        txDni.setText(datos.getString("dni"));
        if (datos.getString("foto")!= null){

            txFoto.setText(datos.getString("foto"));
            Uri myUri = (Uri.parse(txFoto.getText().toString()));
            img.setImageURI(myUri);

        }else{
            txFoto.setVisibility(View.INVISIBLE);
            findViewById(R.id.textView35).setVisibility(View.INVISIBLE);
            img.setVisibility(View.INVISIBLE);
        }
    }
}