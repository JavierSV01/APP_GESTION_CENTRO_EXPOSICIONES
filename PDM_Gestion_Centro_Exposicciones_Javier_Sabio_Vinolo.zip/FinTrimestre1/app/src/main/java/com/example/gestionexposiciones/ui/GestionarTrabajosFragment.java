package com.example.gestionexposiciones.ui;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import android.os.Environment;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gestionexposiciones.Bd;
import com.example.gestionexposiciones.R;

import org.w3c.dom.ls.LSOutput;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import static android.app.Activity.RESULT_OK;
import static android.os.Environment.getExternalStoragePublicDirectory;

public class GestionarTrabajosFragment extends Fragment {

    boolean sdDisponible = false;
    boolean sdAccesoEscritura = false;
    String nombreAux;
    String rutaImagenTrabajo;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_gestionar_trabajos, container, false);
    }

    static final int REQUEST_IMAGE_CAPTURE = 1;

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            if (sdDisponible && sdAccesoEscritura){
                File ruta_sd = getActivity().getExternalFilesDir(null);
                File f = new File(ruta_sd.getAbsolutePath(), nombreAux.replace(" ","") + ".jpg");
                OutputStreamWriter fout = null;
                OutputStream fOut = null;
                fout = new OutputStreamWriter(new FileOutputStream(f) );
                fOut = new FileOutputStream(f);
                imageBitmap.compress(Bitmap.CompressFormat.PNG, 100, fOut);
                rutaImagenTrabajo = f.getAbsolutePath();

                //
                SQLiteOpenHelper bd = new Bd(getContext());
                SQLiteDatabase db = bd.getReadableDatabase();
                db.execSQL("PRAGMA foreign_keys = ON");
                ContentValues newTrabajo = new ContentValues();
                newTrabajo.put("NOMBRETRAB", nombreAux);

                newTrabajo.put("FOTO", rutaImagenTrabajo);
                db.update("TRABAJOS", newTrabajo, "NOMBRETRAB = '" + nombreAux + "'", null);
                //

                fOut.flush();
                fOut.close();
                fout.flush();
                fout.close();
            }
        }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


        //


        String estado = Environment.getExternalStorageState();
        if (estado.equals(Environment.MEDIA_MOUNTED)){
            sdDisponible = true;
            sdAccesoEscritura = true;
        }else if (estado.equals(Environment.MEDIA_MOUNTED_READ_ONLY)){
            sdDisponible = true;
            sdAccesoEscritura = false;
        }else{
            sdDisponible = false;
            sdAccesoEscritura = false;
        }

        //


        Button btAñadir = getView().findViewById(R.id.gesTrabAñadir);
        Button btModificar = getView().findViewById(R.id.gesTrabModificar);
        Button btBorrar = getView().findViewById(R.id.gesTrabBorrar);
        Button btAñadirFoto = getView().findViewById(R.id.gesTrabAñadirFoto);
        final TextView tvTamaño = getView().findViewById(R.id.gesTrabTamaño);
        final TextView tvNombre = getView().findViewById(R.id.gesTrabNombre);
        final TextView tvDescipcion = getView().findViewById(R.id.gesTrabDescripcion);
        final TextView tvPeso = getView().findViewById(R.id.gesTrabPeso);
        final TextView tvDNI = getView().findViewById(R.id.gesTrabDNI);

        btAñadir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tvTamaño.getText().toString().equals("") && !tvNombre.getText().toString().equals("") && !tvDescipcion.getText().toString().equals("") && !tvPeso.getText().toString().equals("") && !tvDNI.getText().toString().equals("")) {
                    SQLiteOpenHelper bd = new Bd(getContext());
                    final SQLiteDatabase db = bd.getReadableDatabase();
                    db.execSQL("PRAGMA foreign_keys = ON");

                    final ContentValues newTrabajo = new ContentValues();
                    newTrabajo.put("NOMBRETRAB", tvNombre.getText().toString());
                    newTrabajo.put("TAMAÑO", tvTamaño.getText().toString());
                    newTrabajo.put("DESCRIPCION", tvDescipcion.getText().toString());
                    newTrabajo.put("PESO", tvPeso.getText().toString());
                    newTrabajo.put("DNIPASAPORTE", tvDNI.getText().toString());

                    AlertDialog alertDialog;
                    AlertDialog.Builder AlertDialogBu = new AlertDialog.Builder(getContext());
                    AlertDialogBu.setTitle(R.string.Confirmacion);
                    AlertDialogBu.setMessage(R.string.ConfirmarOperacion);
                    AlertDialogBu.setIcon(android.R.drawable.ic_dialog_alert);
                    AlertDialogBu.setPositiveButton(R.string.Aceptar, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (db.insert("TRABAJOS", null, newTrabajo) != -1) {
                                Toast.makeText(getActivity(), R.string.tx_añadidoOK, Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(getActivity(), R.string.tx_añadidoERR, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    AlertDialogBu.setNegativeButton(R.string.Cancelar, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(getActivity(), R.string.cancelado, Toast.LENGTH_SHORT).show();
                        }
                    });

                    alertDialog = AlertDialogBu.create();
                    alertDialog.show();

                } else {
                    Toast.makeText(getActivity(), R.string.err_introducir_campos, Toast.LENGTH_SHORT).show();
                }
            }
        });

        btModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tvNombre.getText().toString().equals("")) {
                    SQLiteOpenHelper bd = new Bd(getContext());
                    final SQLiteDatabase db = bd.getReadableDatabase();
                    db.execSQL("PRAGMA foreign_keys = ON");

                    final ContentValues newTrabajo = new ContentValues();
                    newTrabajo.put("NOMBRETRAB", tvNombre.getText().toString());

                    if (!tvDescipcion.getText().toString().equals("")) {
                        newTrabajo.put("DESCRIPCION", tvDescipcion.getText().toString());
                    }
                    if (!tvTamaño.getText().toString().equals("")) {
                        newTrabajo.put("TAMAÑO", tvTamaño.getText().toString());
                    }
                    if (!tvPeso.getText().toString().equals("")) {
                        newTrabajo.put("PESO", tvPeso.getText().toString());
                    }
                    if (!tvDNI.getText().toString().equals("")) {
                        newTrabajo.put("DNIPASAPORTE", tvDNI.getText().toString());

                    }

                    AlertDialog alertDialog;
                    AlertDialog.Builder AlertDialogBu = new AlertDialog.Builder(getContext());
                    AlertDialogBu.setTitle(R.string.Confirmacion);
                    AlertDialogBu.setMessage(R.string.ConfirmarOperacion);
                    AlertDialogBu.setIcon(android.R.drawable.ic_dialog_alert);
                    AlertDialogBu.setPositiveButton(R.string.Aceptar, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (db.update("TRABAJOS", newTrabajo, "NOMBRETRAB = '" + tvNombre.getText().toString() + "'", null) != 0) {
                                Toast.makeText(getActivity(), R.string.tx_modificadoOK, Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(getActivity(), R.string.tx_modificoERR, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    AlertDialogBu.setNegativeButton(R.string.Cancelar, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(getActivity(), R.string.cancelado, Toast.LENGTH_SHORT).show();
                        }
                    });

                    alertDialog = AlertDialogBu.create();
                    alertDialog.show();


                } else {
                    Toast.makeText(getActivity(), R.string.err_introduce_nombre, Toast.LENGTH_SHORT).show();
                }
            }
        });
        btBorrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tvNombre.getText().toString().equals("")) {
                    SQLiteOpenHelper bd = new Bd(getContext());
                    final SQLiteDatabase db = bd.getReadableDatabase();
                    db.execSQL("PRAGMA foreign_keys = ON");
                    AlertDialog alertDialog;
                    AlertDialog.Builder AlertDialogBu = new AlertDialog.Builder(getContext());
                    AlertDialogBu.setTitle(R.string.Confirmacion);
                    AlertDialogBu.setMessage(R.string.ConfirmarOperacion);
                    AlertDialogBu.setIcon(android.R.drawable.ic_dialog_alert);
                    AlertDialogBu.setPositiveButton(R.string.Aceptar, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (db.delete("TRABAJOS", "NOMBRETRAB = '" + tvNombre.getText().toString()+"'", null) == 1) {
                                Toast.makeText(getActivity(), R.string.tx_borradoOK, Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(getActivity(), R.string.tx_borradoERR, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    AlertDialogBu.setNegativeButton(R.string.Cancelar, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(getActivity(), R.string.cancelado, Toast.LENGTH_SHORT).show();
                        }
                    });

                    alertDialog = AlertDialogBu.create();
                    alertDialog.show();

                } else {
                    Toast.makeText(getActivity(), R.string.err_introduce_nombre, Toast.LENGTH_SHORT).show();
                }
            }
        });

        btAñadirFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {

                    if (!tvNombre.getText().toString().equals("")) {
                        nombreAux = tvNombre.getText().toString();
                        dispatchTakePictureIntent();

                        } else {
                        Toast.makeText(getActivity(), R.string.err_introduce_nombre, Toast.LENGTH_SHORT).show();
                    }


                }catch (Exception e){
                    System.out.println(e.getMessage());
                }
            }
        });

    }


}