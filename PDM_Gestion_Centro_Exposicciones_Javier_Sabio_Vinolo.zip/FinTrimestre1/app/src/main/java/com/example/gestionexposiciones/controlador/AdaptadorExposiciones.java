package com.example.gestionexposiciones.controlador;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gestionexposiciones.R;
import com.example.gestionexposiciones.modelo.Exposicion;
import com.example.gestionexposiciones.ui.ExposicionesEnDetalle;
import com.example.gestionexposiciones.ui.ExposicionesFragment;
import com.example.gestionexposiciones.ui.TrabajosFragment;

import java.util.ArrayList;

public class AdaptadorExposiciones extends RecyclerView.Adapter {

    private ArrayList<Exposicion> listaExposiciones;
    Context context;
    public AdaptadorExposiciones(ArrayList<Exposicion> listaExposiciones, Context contexto) {
        this.listaExposiciones = listaExposiciones;
        this.context = contexto;
    }

    @NonNull
    @Override
    public AdaptadorExposicionesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View item_exposiciones = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_exposicion, parent, false);
        AdaptadorExposicionesViewHolder aevh = new AdaptadorExposicionesViewHolder(item_exposiciones);
        return aevh;
    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Exposicion exp = listaExposiciones.get(position);
        final AdaptadorExposicionesViewHolder holderAux = new AdaptadorExposicionesViewHolder(holder.itemView);
        holderAux.txId.setText(Integer.toString(exp.getId()));
        holderAux.txNombre.setText(exp.getNombre());
        holderAux.txFechaInicio.setText(exp.getFechaIni());
        holderAux.txFechaFin.setText(exp.getFechaFin());
        holderAux.txNombre.setOnClickListener(onClickListener);


    }
    View.OnClickListener onClickListener = (new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            TextView nombre = (TextView)view.findViewById(view.getId());
            int posicion = -1;

            for (int i = 0; i < listaExposiciones.size() ; i++) {
                if (nombre.getText().toString().equals(listaExposiciones.get(i).getNombre())){

                    posicion = i;

                }
            }

            Intent intent = new Intent(context, ExposicionesEnDetalle.class);
            intent.putExtra("id", listaExposiciones.get(posicion).getId().toString());
            intent.putExtra("nombre", listaExposiciones.get(posicion).getNombre());
            intent.putExtra("descripcion", listaExposiciones.get(posicion).getDescripcion());
            intent.putExtra("fechaIni", listaExposiciones.get(posicion).getFechaIni());
            intent.putExtra("fechaFin", listaExposiciones.get(posicion).getFechaFin());
            context.startActivity(intent);

        }
    });
    @Override
    public int getItemCount() {
        return listaExposiciones.size();
    }

    public class AdaptadorExposicionesViewHolder extends RecyclerView.ViewHolder {

        private TextView txId;
        private TextView txNombre;
        private TextView txFechaInicio;
        private TextView txFechaFin;
        private Integer posicion;

        public AdaptadorExposicionesViewHolder(@NonNull View itemView) {
            super(itemView);
            txId = itemView.findViewById(R.id.txIdExpo);
            txNombre = itemView.findViewById(R.id.txNombreExpo);
            txFechaInicio = itemView.findViewById(R.id.txFechaInicio);
            txFechaFin = itemView.findViewById(R.id.txFechaFin);
            txNombre.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        }
    }
}
