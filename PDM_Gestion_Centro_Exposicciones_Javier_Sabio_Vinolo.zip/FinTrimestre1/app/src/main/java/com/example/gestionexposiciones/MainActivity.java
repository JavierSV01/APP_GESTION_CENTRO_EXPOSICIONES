package com.example.gestionexposiciones;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.material.navigation.NavigationView;

import androidx.appcompat.app.AlertDialog;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;

    NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try{

            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            DrawerLayout drawer = findViewById(R.id.drawer_layout);
            NavigationView navigationView = findViewById(R.id.nav_view);
            // Passing each menu ID as a set of Ids because each
            // menu should be considered as top level destinations.
            mAppBarConfiguration = new AppBarConfiguration.Builder(
                    R.id.nav_exposiciones, R.id.nav_artistas, R.id.nav_trabajos, R.id.nav_Inicio, R.id.nav_gestionarExp)
                    .setDrawerLayout(drawer)
                    .build();
            navController = Navigation.findNavController(this, R.id.nav_host_fragment);
            NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
            NavigationUI.setupWithNavController(navigationView, navController);


        }catch (Exception e){
            System.out.println(e.getMessage());
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        AlertDialog alertDialog2;
        AlertDialog.Builder alertDialogBu2 = new AlertDialog.Builder(this);
        alertDialogBu2.setTitle(R.string.dialog_gestionar);
        alertDialogBu2.setIcon(android.R.drawable.ic_dialog_info);
        String exposiciones = getString(R.string.menu_exposiciones);
        String artistas = getString(R.string.menu_artistas);
        String trabajos = getString(R.string.menu_trabajos);
        String comentarios = getString(R.string.menu_comentarios);
        String exposicionesArt = getString(R.string.menu_ExposicionesArrtistas);
        CharSequence opciones[] = {exposiciones,artistas, trabajos, comentarios,exposicionesArt};
        alertDialogBu2.setItems(opciones, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                switch (item){
                    case 0:
                        navController.navigate(R.id.nav_gestionarExp);
                        break;
                    case 1:
                        navController.navigate(R.id.nav_GestionarArt);
                        break;
                    case 2:
                        navController.navigate(R.id.nav_GestionarTrab);
                        break;
                    case 3:
                        navController.navigate(R.id.nav_GestionarCom);
                        break;
                    case 4:
                        navController.navigate(R.id.gesExposicionesDeArtistasFragment);
                        break;
                }
            }
        });

        alertDialog2 = alertDialogBu2.create();

        switch (item.getItemId()) {
            case R.id.action_gestionar:
                alertDialog2.show();
                return true;
            case R.id.action_artistas:
                navController.navigate(R.id.nav_artistas);
                return true;
            case R.id.action_exposiciones:
                navController.navigate(R.id.nav_exposiciones);
                return true;
            case R.id.action_trabajos:
                navController.navigate(R.id.nav_trabajos);
                return true;
            case R.id.action_inicio:
                navController.navigate(R.id.nav_Inicio);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }



    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
}