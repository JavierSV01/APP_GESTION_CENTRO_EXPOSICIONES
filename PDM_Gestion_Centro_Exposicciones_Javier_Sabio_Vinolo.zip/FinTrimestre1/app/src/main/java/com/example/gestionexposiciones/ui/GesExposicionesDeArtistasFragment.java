package com.example.gestionexposiciones.ui;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gestionexposiciones.Bd;
import com.example.gestionexposiciones.R;

public class GesExposicionesDeArtistasFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_ges_exposiciones_de_artistas, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        super.onActivityCreated(savedInstanceState);
        Button btAñadir = getView().findViewById(R.id.btArtExpAñadir);
        Button btBorrar = getView().findViewById(R.id.btArtExpBorrar);
        final TextView tvDNI = getView().findViewById(R.id.txArtExpDNIArt);
        final TextView tvIDExp = getView().findViewById(R.id.txArtExpIDExp);



        btAñadir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tvDNI.getText().toString().equals("") && !tvIDExp.getText().toString().equals("")){
                    SQLiteOpenHelper bd = new Bd(getContext());
                    SQLiteDatabase db = bd.getReadableDatabase();
                    db.execSQL("PRAGMA foreign_keys = ON");

                    ContentValues newExponen = new ContentValues();
                    newExponen.put("IDEXPOSICION", tvIDExp.getText().toString());
                    newExponen.put("DNIPASAPORTE", tvDNI.getText().toString());

                    if (db.insert("EXPONEN", null, newExponen) != -1) {
                        Toast.makeText(getActivity(), R.string.tx_añadidoOK, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getActivity(), R.string.tx_añadidoERR, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getActivity(), R.string.err_introducir_campos, Toast.LENGTH_SHORT).show();
                }
            }
        });


        btBorrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tvDNI.getText().toString().equals("")) {
                    SQLiteOpenHelper bd = new Bd(getContext());
                    SQLiteDatabase db = bd.getReadableDatabase();
                    db.execSQL("PRAGMA foreign_keys = ON");

                    if (db.delete("EXPONEN", "DNIPASAPORTE = '" + tvDNI.getText().toString() + "' AND IDEXPOSICION = " + tvIDExp.getText().toString(), null) == 1) {
                        Toast.makeText(getActivity(), R.string.tx_borradoOK, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getActivity(), R.string.tx_borradoERR, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getActivity(), R.string.err_introduce_id, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}