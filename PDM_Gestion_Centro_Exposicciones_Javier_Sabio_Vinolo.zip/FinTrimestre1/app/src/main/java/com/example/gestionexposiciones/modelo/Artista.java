package com.example.gestionexposiciones.modelo;

public class Artista {

    String DNIPasaporte, nombre, direccion, poblacion, provincia, pais, email, webBlog, fechaNacimiento;
    Integer movilTrab, movilPers, tlffijo;

    public Artista(String DNIPasaporte, String nombre, String direccion, String poblacion, String provincia, String pais, String email, String webBlog, String fechaNacimiento, Integer movilTrab, Integer movilPers, Integer tlffijo) {
        this.DNIPasaporte = DNIPasaporte;
        this.nombre = nombre;
        this.direccion = direccion;
        this.poblacion = poblacion;
        this.provincia = provincia;
        this.pais = pais;
        this.email = email;
        this.webBlog = webBlog;
        this.fechaNacimiento = fechaNacimiento;
        this.movilTrab = movilTrab;
        this.movilPers = movilPers;
        this.tlffijo = tlffijo;
    }

    public String getDNIPasaporte() {
        return DNIPasaporte;
    }

    public void setDNIPasaporte(String DNIPasaporte) {
        this.DNIPasaporte = DNIPasaporte;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getPoblacion() {
        return poblacion;
    }

    public void setPoblacion(String poblacion) {
        this.poblacion = poblacion;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWebBlog() {
        return webBlog;
    }

    public void setWebBlog(String webBlog) {
        this.webBlog = webBlog;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public Integer getMovilTrab() {
        return movilTrab;
    }

    public void setMovilTrab(Integer movilTrab) {
        this.movilTrab = movilTrab;
    }

    public Integer getMovilPers() {
        return movilPers;
    }

    public void setMovilPers(Integer movilPers) {
        this.movilPers = movilPers;
    }

    public Integer getTlffijo() {
        return tlffijo;
    }

    public void setTlffijo(Integer tlffijo) {
        this.tlffijo = tlffijo;
    }
}
