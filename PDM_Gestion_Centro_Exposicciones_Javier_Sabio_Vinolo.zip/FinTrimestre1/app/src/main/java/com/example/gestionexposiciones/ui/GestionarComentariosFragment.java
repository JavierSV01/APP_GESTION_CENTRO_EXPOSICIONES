package com.example.gestionexposiciones.ui;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gestionexposiciones.Bd;
import com.example.gestionexposiciones.R;

public class GestionarComentariosFragment extends Fragment {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_gestionar_comentarios, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Button btAñadir = getView().findViewById(R.id.btComAñadir);
        Button btModificar = getView().findViewById(R.id.btComModificar);
        final TextView tvIdExp = getView().findViewById(R.id.txComIdExpo);
        final TextView tvNombreTrabajo = getView().findViewById(R.id.txComNombreTrabajo);
        final TextView tvComentario = getView().findViewById(R.id.txComComentario);

        btAñadir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tvIdExp.getText().toString().equals("") && !tvNombreTrabajo.getText().toString().equals("") && !tvComentario.getText().toString().equals("") ) {
                    SQLiteOpenHelper bd = new Bd(getContext());
                    final SQLiteDatabase db = bd.getReadableDatabase();
                    db.execSQL("PRAGMA foreign_keys = ON");

                    final ContentValues newExposicion = new ContentValues();
                    newExposicion.put("IDEXPOSICION", tvIdExp.getText().toString());
                    newExposicion.put("NOMBRETRAB", tvNombreTrabajo.getText().toString());
                    newExposicion.put("COMENTARIO", tvComentario.getText().toString());

                    AlertDialog alertDialog;
                    AlertDialog.Builder AlertDialogBu = new AlertDialog.Builder(getContext());
                    AlertDialogBu.setTitle(R.string.Confirmacion);
                    AlertDialogBu.setMessage(R.string.ConfirmarOperacion);
                    AlertDialogBu.setIcon(android.R.drawable.ic_dialog_alert);
                    AlertDialogBu.setPositiveButton(R.string.Aceptar, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (db.insert("COMENTARIOs", null, newExposicion) != -1) {
                                Toast.makeText(getActivity(), R.string.tx_añadidoOK, Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(getActivity(), R.string.tx_añadidoERR, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    AlertDialogBu.setNegativeButton(R.string.Cancelar, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(getActivity(), R.string.cancelado, Toast.LENGTH_SHORT).show();
                        }
                    });

                    alertDialog = AlertDialogBu.create();
                    alertDialog.show();


                } else {
                    Toast.makeText(getActivity(), R.string.err_introducir_campos, Toast.LENGTH_SHORT).show();
                }
            }
        });

        btModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tvIdExp.getText().toString().equals("") && !tvNombreTrabajo.getText().toString().equals("") && !tvComentario.getText().toString().equals("") ) {
                    SQLiteOpenHelper bd = new Bd(getContext());
                    final SQLiteDatabase db = bd.getReadableDatabase();
                    db.execSQL("PRAGMA foreign_keys = ON");

                    final ContentValues newExposicion = new ContentValues();
                    newExposicion.put("NOMBRETRAB", tvNombreTrabajo.getText().toString());
                    newExposicion.put("IDEXPOSICION", tvIdExp.getText().toString());
                    newExposicion.put("COMENTARIO", tvComentario.getText().toString());
                    AlertDialog alertDialog;
                    AlertDialog.Builder AlertDialogBu = new AlertDialog.Builder(getContext());
                    AlertDialogBu.setTitle(R.string.Confirmacion);
                    AlertDialogBu.setMessage(R.string.ConfirmarOperacion);
                    AlertDialogBu.setIcon(android.R.drawable.ic_dialog_alert);
                    AlertDialogBu.setPositiveButton(R.string.Aceptar, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (db.update("COMENTARIOS", newExposicion, "NOMBRETRAB = '" + tvNombreTrabajo.getText().toString()+"' AND IDEXPOSICION = " + tvIdExp.getText().toString(), null) != 0) {
                                Toast.makeText(getActivity(), R.string.tx_modificadoOK, Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(getActivity(), R.string.tx_modificoERR, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    AlertDialogBu.setNegativeButton(R.string.Cancelar, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(getActivity(), R.string.cancelado, Toast.LENGTH_SHORT).show();
                        }
                    });

                    alertDialog = AlertDialogBu.create();
                    alertDialog.show();

                } else {
                    Toast.makeText(getActivity(), R.string.err_introducir_campos, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}