package com.example.gestionexposiciones.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.widget.TextView;

import com.example.gestionexposiciones.Bd;
import com.example.gestionexposiciones.R;
import com.example.gestionexposiciones.controlador.AdaptadorArtistas;
import com.example.gestionexposiciones.controlador.AdaptadorComentarios;
import com.example.gestionexposiciones.modelo.Artista;
import com.example.gestionexposiciones.modelo.Comentario;

import java.util.ArrayList;

public class ExposicionesEnDetalle extends AppCompatActivity {
    private RecyclerView.Adapter adaptadorExponen;
    private RecyclerView rvArt;
    private RecyclerView.Adapter adaptadorComentario;
    private RecyclerView rvCom;
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerView.LayoutManager layoutManagerCom;

    ArrayList<Artista> listaArt = new ArrayList<>();
    ArrayList<String> listaArtAux = new ArrayList<>();
    ArrayList<Comentario> listaComentariosFin = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exposiciones_en_detalle);

        Bundle datos = this.getIntent().getExtras();
        TextView nom = findViewById(R.id.txNombre);
        TextView descripcion = findViewById(R.id.descripcion);
        TextView fechaIni = findViewById(R.id.Inicio);
        TextView fechaFin = findViewById(R.id.Fin);
        TextView id = findViewById(R.id.id);

        nom.setText(datos.getString("nombre"));
        descripcion.setText(datos.getString("descripcion"));
        id.setText(datos.getString("id"));
        fechaFin.setText(datos.getString("fechaFin"));
        fechaIni.setText(datos.getString("fechaIni"));

        SQLiteOpenHelper bd = new Bd(this);
        SQLiteDatabase db = bd.getReadableDatabase();

        String[] columnas = new String[12];
        columnas[0] = "DNIPASAPORTE";
        columnas[1] = "NOMBRE";
        columnas[2] = "DIRECCION";
        columnas[3] = "POBLACION";
        columnas[4] = "PROVINCIA";
        columnas[5] = "PAIS";
        columnas[6] = "MOVILTRABAJO";
        columnas[7] = "MOVILPERSONAL";
        columnas[8] = "TELEFONOFIJO";
        columnas[9] = "EMAIL";
        columnas[10] = "WEBBLOG";
        columnas[11] = "FECHANACIMIENTO";

        String[] columnasExponen = new String[2];
        columnasExponen[0] = "IDEXPOSICION";
        columnasExponen[1] = "DNIPASAPORTE";

            String[] columnasComentario = new String[3];
            columnasComentario[0] = "IDEXPOSICION";
            columnasComentario[1] = "NOMBRETRAB";
            columnasComentario[2] = "COMENTARIO";


        Cursor listaExponen = db.query("EXPONEN", columnasExponen, "IDEXPOSICION = " + id.getText().toString(), null, null, null, null);
        Cursor listaCometarios = db.query("COMENTARIOS", columnasComentario, "IDEXPOSICION = " + id.getText().toString(), null, null, null, null);
            listaComentariosFin.clear();
            if (listaCometarios.moveToFirst()) {
                do {
                    String idexposicion = listaCometarios.getString(listaCometarios.getColumnIndex("IDEXPOSICION"));
                    String nombretrab = listaCometarios.getString(listaCometarios.getColumnIndex("NOMBRETRAB"));
                    String comentario = listaCometarios.getString(listaCometarios.getColumnIndex("COMENTARIO"));
                    Comentario com = new Comentario(idexposicion, nombretrab, comentario);
                    listaComentariosFin.add(com);
                } while (listaCometarios.moveToNext());
            }

        if (listaExponen.moveToFirst()) {
            do {
                String dni = listaExponen.getString(listaExponen.getColumnIndex("DNIPASAPORTE"));
                listaArtAux.add(dni);
            } while (listaExponen.moveToNext());
        }

        Cursor listaArtistas = db.query("ARTISTAS", columnas, null, null, null, null, null);
        listaArt.clear();
        if (listaArtistas.moveToFirst()) {
            do {
                String dni = listaArtistas.getString(listaArtistas.getColumnIndex("DNIPASAPORTE"));
                String nombre = listaArtistas.getString(listaArtistas.getColumnIndex("NOMBRE"));
                String direccion = listaArtistas.getString(listaArtistas.getColumnIndex("DIRECCION"));
                String poblacion = listaArtistas.getString(listaArtistas.getColumnIndex("POBLACION"));
                String provincia = listaArtistas.getString(listaArtistas.getColumnIndex("PROVINCIA"));
                String pais = listaArtistas.getString(listaArtistas.getColumnIndex("PAIS"));
                Integer moviltrabajo = listaArtistas.getInt(listaArtistas.getColumnIndex("MOVILTRABAJO"));
                Integer movilpersonal = listaArtistas.getInt(listaArtistas.getColumnIndex("MOVILPERSONAL"));
                Integer telefonofijo = listaArtistas.getInt(listaArtistas.getColumnIndex("TELEFONOFIJO"));
                String email = listaArtistas.getString(listaArtistas.getColumnIndex("EMAIL"));
                String webblog = listaArtistas.getString(listaArtistas.getColumnIndex("WEBBLOG"));
                String fechanacimiento= listaArtistas.getString(listaArtistas.getColumnIndex("FECHANACIMIENTO"));

                Artista art = new Artista(dni, nombre, direccion, poblacion,provincia, pais, email, webblog, fechanacimiento,moviltrabajo, movilpersonal, telefonofijo);

                for (int i = 0; i < listaArtAux.size(); i++) {

                    if (art.getDNIPasaporte().equals(listaArtAux.get(i))){
                        listaArt.add(art);
                    }
                }
            } while (listaArtistas.moveToNext());
        }

            rvArt = this.findViewById(R.id.recyclerViewUno);
            layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
            rvArt.setLayoutManager(layoutManager);
            adaptadorExponen = new AdaptadorArtistas(listaArt, this);
            rvArt.setAdapter(adaptadorExponen);

            rvCom = this.findViewById(R.id.recyclerViewDos);
            layoutManagerCom = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
            rvCom.setLayoutManager(layoutManagerCom);
            adaptadorComentario = new AdaptadorComentarios(listaComentariosFin);
            rvCom.setAdapter(adaptadorComentario);


        }catch(Exception e){
            System.out.println(e.getMessage());
        }


    }

}