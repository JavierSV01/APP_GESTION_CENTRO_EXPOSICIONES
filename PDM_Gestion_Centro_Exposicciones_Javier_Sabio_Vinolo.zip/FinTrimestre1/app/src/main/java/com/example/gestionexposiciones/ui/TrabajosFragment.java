package com.example.gestionexposiciones.ui;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gestionexposiciones.Bd;
import com.example.gestionexposiciones.R;
import com.example.gestionexposiciones.controlador.AdaptadorArtistas;
import com.example.gestionexposiciones.controlador.AdaptadorTrabajos;
import com.example.gestionexposiciones.modelo.Artista;
import com.example.gestionexposiciones.modelo.Trabajo;

import java.util.ArrayList;

public class TrabajosFragment extends Fragment {

    private RecyclerView.Adapter adaptador;
    private RecyclerView rvTrab;
    private RecyclerView.LayoutManager layoutManager;

    ArrayList<Trabajo> listaTrab = new ArrayList<>();


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_trabajos, container, false);
        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        SQLiteOpenHelper bd = new Bd(getContext());
        SQLiteDatabase db = bd.getReadableDatabase();

        String[] columnas = new String[6];
        columnas[0] = "NOMBRETRAB";
        columnas[1] = "DESCRIPCION";
        columnas[2] = "TAMAÑO";
        columnas[3] = "PESO";
        columnas[4] = "DNIPASAPORTE";
        columnas[5] = "FOTO";

        Cursor listaTrabajos = db.query("TRABAJOS", columnas, null, null, null, null, null);
        listaTrab.clear();
        if (listaTrabajos.moveToFirst()) {
            do {
                String nombretrab = listaTrabajos.getString(listaTrabajos.getColumnIndex("NOMBRETRAB"));
                String descripcion = listaTrabajos.getString(listaTrabajos.getColumnIndex("DESCRIPCION"));
                String tamaño = listaTrabajos.getString(listaTrabajos.getColumnIndex("TAMAÑO"));
                String peso = listaTrabajos.getString(listaTrabajos.getColumnIndex("PESO"));
                String dnipasaporte = listaTrabajos.getString(listaTrabajos.getColumnIndex("DNIPASAPORTE"));
                String foto = listaTrabajos.getString(listaTrabajos.getColumnIndex("FOTO"));

                Trabajo trab = new Trabajo(nombretrab, descripcion, tamaño, peso, dnipasaporte, foto);
                listaTrab.add(trab);
            } while (listaTrabajos.moveToNext());
        }
        try {
            rvTrab = getView().findViewById(R.id.recyclerViewTrab);
            layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
            rvTrab.setLayoutManager(layoutManager);
            adaptador = new AdaptadorTrabajos(listaTrab, getContext());
            rvTrab.setAdapter(adaptador);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }

    }
}