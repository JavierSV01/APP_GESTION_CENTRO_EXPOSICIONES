package com.example.gestionexposiciones.controlador;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gestionexposiciones.R;
import com.example.gestionexposiciones.modelo.Artista;
import com.example.gestionexposiciones.modelo.Exposicion;
import com.example.gestionexposiciones.ui.ArtistasEnDetalle;
import com.example.gestionexposiciones.ui.ExposicionesEnDetalle;

import java.util.ArrayList;

public class AdaptadorArtistas extends RecyclerView.Adapter  {

    private ArrayList<Artista> listaArtistas;
    Context contexto;

    public AdaptadorArtistas(ArrayList<Artista> listaArtistas, Context contexto){
        this.listaArtistas = listaArtistas;
        this.contexto = contexto;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View item_artista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_artista, parent, false);
        AdaptadorArtistas.AdaptadorArtistaViewHolder aavh = new  AdaptadorArtistas.AdaptadorArtistaViewHolder(item_artista);
        return aavh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Artista art = listaArtistas.get(position);
        AdaptadorArtistas.AdaptadorArtistaViewHolder holderAux = new AdaptadorArtistas.AdaptadorArtistaViewHolder(holder.itemView);
        holderAux.txNombre.setText(art.getNombre());
        holderAux.txPais.setText(art.getPais());
        holderAux.txTlf.setText(art.getMovilTrab().toString());
        holderAux.txDNI.setText(art.getDNIPasaporte());

        holderAux.txNombre.setHint(holderAux.txDNI.getText());
        holderAux.txNombre.setOnClickListener(onClickListener);
    }

    View.OnClickListener onClickListener = (new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            TextView idArt = (TextView)view.findViewById(view.getId());
            int posicion = -1;

            for (int i = 0; i < listaArtistas.size() ; i++) {
                if (idArt.getHint().toString().equals(listaArtistas.get(i).getDNIPasaporte())){

                    posicion = i;

                }
            }

            Intent intent = new Intent(contexto, ArtistasEnDetalle.class);
            intent.putExtra("dni", listaArtistas.get(posicion).getDNIPasaporte());
            intent.putExtra("nombre", listaArtistas.get(posicion).getNombre());
            intent.putExtra("direccion", listaArtistas.get(posicion).getDireccion());
            intent.putExtra("poblacion", listaArtistas.get(posicion).getPoblacion());
            intent.putExtra("provincia", listaArtistas.get(posicion).getProvincia());
            intent.putExtra("pais", listaArtistas.get(posicion).getPais());
            intent.putExtra("movilTrab", listaArtistas.get(posicion).getMovilTrab().toString());
            intent.putExtra("movilPersonal", listaArtistas.get(posicion).getMovilPers().toString());
            intent.putExtra("fijo", listaArtistas.get(posicion).getTlffijo().toString());
            intent.putExtra("email", listaArtistas.get(posicion).getEmail());
            intent.putExtra("webblog", listaArtistas.get(posicion).getWebBlog());
            intent.putExtra("fechaNacimiento", listaArtistas.get(posicion).getFechaNacimiento());
            contexto.startActivity(intent);

        }
    });

    @Override
    public int getItemCount() {
        return listaArtistas.size();
    }

    public class AdaptadorArtistaViewHolder extends RecyclerView.ViewHolder {

        private TextView txNombre;
        private TextView txPais;
        private TextView txTlf;
        private TextView txDNI;

        public AdaptadorArtistaViewHolder(@NonNull View itemView) {
            super(itemView);
            txNombre = itemView.findViewById(R.id.txNombreArt);
            txPais = itemView.findViewById(R.id.txPaisArt);
            txTlf = itemView.findViewById(R.id.txTlfArt);
            txDNI =itemView.findViewById(R.id.txDniArt);
        }

    }
}
