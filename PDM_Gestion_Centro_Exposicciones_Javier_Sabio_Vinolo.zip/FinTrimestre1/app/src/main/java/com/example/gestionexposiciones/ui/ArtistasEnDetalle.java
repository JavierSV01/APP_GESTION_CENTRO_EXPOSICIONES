package com.example.gestionexposiciones.ui;


import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gestionexposiciones.MainActivity;
import com.example.gestionexposiciones.R;

import java.util.Date;

public class ArtistasEnDetalle extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artistas_en_detalle);

        Button btLlamar = findViewById(R.id.btLlamar);
        Button btEmail = findViewById(R.id.btMandarEmail);
        Button btFelicitar = findViewById(R.id.btFelicitar);
        btFelicitar.setVisibility(View.INVISIBLE);

        final RadioButton rbFijo = findViewById(R.id.rbFijo);
        final RadioButton rbMovPer = findViewById(R.id.rbMovPer);
        final RadioButton rbMovTrab = findViewById(R.id.rbMovTrab);

        Bundle datos = this.getIntent().getExtras();
        TextView DNI = findViewById(R.id.txDNI);
        TextView nombre = findViewById(R.id.txNom);
        TextView direccion = findViewById(R.id.txDireccion);
        TextView poblacion = findViewById(R.id.txPoblacion);
        TextView provincia = findViewById(R.id.txProvincia);
        TextView pais = findViewById(R.id.txPais);
        final TextView movilTrab = findViewById(R.id.txMovTra);
        final TextView movilPers = findViewById(R.id.txMovPer);
        final TextView fijo = findViewById(R.id.txFijo);
        final TextView email = findViewById(R.id.txEmail);
        TextView webBlog = findViewById(R.id.txWebBlog);
        TextView fechaNaci = findViewById(R.id.txFechaNaci);

        DNI.setText(datos.getString("dni"));
        nombre.setText(datos.getString("nombre"));
        direccion.setText(datos.getString("direccion"));
        poblacion.setText(datos.getString("poblacion"));
        provincia.setText(datos.getString("provincia"));
        pais.setText(datos.getString("pais"));
        movilTrab.setText(datos.getString("movilTrab"));
        movilPers.setText(datos.getString("movilPersonal"));
        fijo.setText(datos.getString("fijo"));
        email.setText(datos.getString("email"));
        webBlog.setText(datos.getString("webblog"));
        fechaNaci.setText(datos.getString("fechaNacimiento"));

        btLlamar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(rbFijo.isChecked()){
                    dialPhoneNumber(fijo.getText().toString());
                }
                if(rbMovTrab.isChecked()){
                    dialPhoneNumber(movilTrab.getText().toString());
                }
                if(rbMovPer.isChecked()){
                    dialPhoneNumber(movilPers.getText().toString());
                }
            }
        });

        btEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] emils = new String[1];
                emils[0] = email.getText().toString();

                composeEmail(emils, "Expo");
            }
        });



        btFelicitar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = movilPers.getText().toString();
                String text = "Felicidadeeees!!!!!";
                SmsManager sms = SmsManager.getDefault();
                sms.sendTextMessage(phone, null, text , null, null);
                Toast.makeText(v.getContext(), "Mensaje enviado", Toast.LENGTH_SHORT).show();
            }
        });

        Date fecha = new Date();
        try {
            Integer dia1 = Integer.parseInt(fechaNaci.getText().toString().substring(0, 2));
            Integer mes1 = Integer.parseInt(fechaNaci.getText().toString().substring(3, 5));
            if (mes1 == fecha.getMonth() + 1 && dia1 == fecha.getDay() - 1) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS,}, 1000);
                }

                btFelicitar.setVisibility(View.VISIBLE);
            }
        }catch (Exception e){
            System.out.println(e.getMessage());

        }

    }
    public void dialPhoneNumber(String phoneNumber) {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + phoneNumber));
            startActivity(intent);
    }
    public void composeEmail(String[] addresses, String subject) {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:")); // only email apps should handle this
        intent.putExtra(Intent.EXTRA_EMAIL, addresses);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);

        startActivity(intent);

    }



}