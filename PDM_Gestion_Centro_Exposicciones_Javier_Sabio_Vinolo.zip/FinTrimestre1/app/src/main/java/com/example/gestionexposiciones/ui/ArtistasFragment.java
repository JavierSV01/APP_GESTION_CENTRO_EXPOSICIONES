package com.example.gestionexposiciones.ui;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gestionexposiciones.Bd;
import com.example.gestionexposiciones.R;
import com.example.gestionexposiciones.controlador.AdaptadorArtistas;
import com.example.gestionexposiciones.controlador.AdaptadorExposiciones;
import com.example.gestionexposiciones.modelo.Artista;
import com.example.gestionexposiciones.modelo.Exposicion;

import java.util.ArrayList;

public class ArtistasFragment extends Fragment {

    private RecyclerView.Adapter adaptador;
    private RecyclerView rvArt;
    private RecyclerView.LayoutManager layoutManager;

    ArrayList<Artista> listaArt = new ArrayList<>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_artistas, container, false);

        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        try {
        super.onActivityCreated(savedInstanceState);

        SQLiteOpenHelper bd = new Bd(getContext());
        SQLiteDatabase db = bd.getReadableDatabase();

        String[] columnas = new String[12];
        columnas[0] = "DNIPASAPORTE";
        columnas[1] = "NOMBRE";
        columnas[2] = "DIRECCION";
        columnas[3] = "POBLACION";
        columnas[4] = "PROVINCIA";
        columnas[5] = "PAIS";
        columnas[6] = "MOVILTRABAJO";
        columnas[7] = "MOVILPERSONAL";
        columnas[8] = "TELEFONOFIJO";
        columnas[9] = "EMAIL";
        columnas[10] = "WEBBLOG";
        columnas[11] = "FECHANACIMIENTO";


        Cursor listaArtistas = db.query("ARTISTAS", columnas, null, null, null, null, null);
        listaArt.clear();
        if (listaArtistas.moveToFirst()) {
            do {
                String dni = listaArtistas.getString(listaArtistas.getColumnIndex("DNIPASAPORTE"));
                String nombre = listaArtistas.getString(listaArtistas.getColumnIndex("NOMBRE"));
                String direccion = listaArtistas.getString(listaArtistas.getColumnIndex("DIRECCION"));
                String poblacion = listaArtistas.getString(listaArtistas.getColumnIndex("POBLACION"));
                String provincia = listaArtistas.getString(listaArtistas.getColumnIndex("PROVINCIA"));
                String pais = listaArtistas.getString(listaArtistas.getColumnIndex("PAIS"));
                Integer moviltrabajo = listaArtistas.getInt(listaArtistas.getColumnIndex("MOVILTRABAJO"));
                Integer movilpersonal = listaArtistas.getInt(listaArtistas.getColumnIndex("MOVILPERSONAL"));
                Integer telefonofijo = listaArtistas.getInt(listaArtistas.getColumnIndex("TELEFONOFIJO"));
                String email = listaArtistas.getString(listaArtistas.getColumnIndex("EMAIL"));
                String webblog = listaArtistas.getString(listaArtistas.getColumnIndex("WEBBLOG"));
                String fechanacimiento= listaArtistas.getString(listaArtistas.getColumnIndex("FECHANACIMIENTO"));

                Artista art = new Artista(dni, nombre, direccion, poblacion,provincia, pais, email, webblog, fechanacimiento,moviltrabajo, movilpersonal, telefonofijo);
                listaArt.add(art);
            } while (listaArtistas.moveToNext());
        }

            rvArt = getView().findViewById(R.id.recyclerViewArt);
            layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
            rvArt.setLayoutManager(layoutManager);
            adaptador = new AdaptadorArtistas(listaArt, getContext());
            rvArt.setAdapter(adaptador);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }

    }


}