package com.example.gestionexposiciones.ui;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gestionexposiciones.Bd;
import com.example.gestionexposiciones.R;
import com.example.gestionexposiciones.controlador.AdaptadorExposiciones;
import com.example.gestionexposiciones.modelo.Exposicion;

import java.util.ArrayList;

public class ExposicionesFragment extends Fragment {

    private RecyclerView.Adapter adaptador;
    private RecyclerView rvExp;
    private RecyclerView.LayoutManager layoutManager;

    ArrayList<Exposicion> listaExp = new ArrayList<>();

    public interface  RecyclerViewOnItemClickListener {
        void onClick(View v, int position);
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_exposiciones, container, false);
        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        SQLiteOpenHelper bd = new Bd(getContext());
        SQLiteDatabase db = bd.getReadableDatabase();

        String[] columnas = new String[5];
        columnas[0] = "IDEXPOSICION";
        columnas[1] = "NOMBREEXP";
        columnas[2] = "DESCRIPCION";
        columnas[3] = "FECHAINICIO";
        columnas[4] = "FECHAFIN";

        Cursor listaExposiciones = db.query("EXPOSICIONES", columnas, null, null, null, null, null);
        listaExp.clear();
        if (listaExposiciones.moveToFirst()) {
            do {
                Integer id = listaExposiciones.getInt(listaExposiciones.getColumnIndex("IDEXPOSICION"));
                String nombre = listaExposiciones.getString(listaExposiciones.getColumnIndex("NOMBREEXP"));
                String descripcion = listaExposiciones.getString(listaExposiciones.getColumnIndex("DESCRIPCION"));
                String fechaIni = listaExposiciones.getString(listaExposiciones.getColumnIndex("FECHAINICIO"));
                String fechaFin = listaExposiciones.getString(listaExposiciones.getColumnIndex("FECHAFIN"));
                Exposicion exp = new Exposicion(id, nombre, descripcion, fechaIni, fechaFin);
                listaExp.add(exp);
          } while (listaExposiciones.moveToNext());
        }
        try {
            rvExp = getView().findViewById(R.id.recyclerViewExp);
            layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
            rvExp.setLayoutManager(layoutManager);
            adaptador = new AdaptadorExposiciones(listaExp, getContext());
            rvExp.setAdapter(adaptador);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }



    }
}
