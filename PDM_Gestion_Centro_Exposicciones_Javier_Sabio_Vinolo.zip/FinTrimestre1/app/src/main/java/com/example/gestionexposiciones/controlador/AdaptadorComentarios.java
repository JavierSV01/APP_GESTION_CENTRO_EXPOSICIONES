package com.example.gestionexposiciones.controlador;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gestionexposiciones.R;
import com.example.gestionexposiciones.modelo.Comentario;

import java.util.ArrayList;

public class AdaptadorComentarios extends  RecyclerView.Adapter{
    private ArrayList<Comentario> listaComentarios;

    public AdaptadorComentarios(ArrayList<Comentario> listaComentarios) {
        this.listaComentarios = listaComentarios;
    }

    @NonNull
    @Override
    public AdaptadorComentarios.AdaptadorComentarioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View item_comentario = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_comentario, parent, false);
        AdaptadorComentarios.AdaptadorComentarioViewHolder aevh = new AdaptadorComentarios.AdaptadorComentarioViewHolder(item_comentario);
        return aevh;
    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Comentario com = listaComentarios.get(position);
        final AdaptadorComentarios.AdaptadorComentarioViewHolder holderAux = new AdaptadorComentarios.AdaptadorComentarioViewHolder(holder.itemView);
        holderAux.txComentario.setText(com.getComentario());
        holderAux.txTrabajo.setText(com.getNombreTrabajo());

    }

    @Override
    public int getItemCount() {
        return listaComentarios.size();
    }

    public class AdaptadorComentarioViewHolder extends RecyclerView.ViewHolder {

        private TextView txTrabajo;
        private TextView txComentario;

        public AdaptadorComentarioViewHolder(@NonNull View itemView) {
            super(itemView);
            txTrabajo = itemView.findViewById(R.id.txComentarioTrabajo);
            txComentario = itemView.findViewById(R.id.txComentarioCom);
        }
    }
}
