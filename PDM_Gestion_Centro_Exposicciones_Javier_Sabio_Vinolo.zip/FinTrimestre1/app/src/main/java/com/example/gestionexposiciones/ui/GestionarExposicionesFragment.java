package com.example.gestionexposiciones.ui;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gestionexposiciones.Bd;
import com.example.gestionexposiciones.R;

public class GestionarExposicionesFragment extends Fragment {


    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {


        return inflater.inflate(R.layout.fragment_gestionar_exposicion, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Button btAñadir = getView().findViewById(R.id.gesExpAñadir);
        Button btModificar = getView().findViewById(R.id.gesExpModificar);
        Button btBorrar = getView().findViewById(R.id.gesExpBorrar);
        final TextView tvId = getView().findViewById(R.id.gesExpID);
        final TextView tvNombre = getView().findViewById(R.id.gesExpNombre);
        final TextView tvDescipcion = getView().findViewById(R.id.gesExpDescripcion);
        final TextView tvFechaIni = getView().findViewById(R.id.gesExpFechaIni);
        final TextView tvFechaFin = getView().findViewById(R.id.gesExpFechaFin);

        btAñadir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tvId.getText().toString().equals("") && !tvDescipcion.getText().toString().equals("") && !tvNombre.getText().toString().equals("") && !tvFechaIni.getText().toString().equals("") && !tvFechaFin.getText().toString().equals("")) {
                    SQLiteOpenHelper bd = new Bd(getContext());
                    final SQLiteDatabase db = bd.getReadableDatabase();
                    db.execSQL("PRAGMA foreign_keys = ON");

                    final ContentValues newExposicion = new ContentValues();
                    newExposicion.put("IDEXPOSICION", tvId.getText().toString());
                    newExposicion.put("NOMBREEXP", tvNombre.getText().toString());
                    newExposicion.put("DESCRIPCION", tvDescipcion.getText().toString());
                    newExposicion.put("FECHAINICIO", tvFechaIni.getText().toString());
                    newExposicion.put("FECHAFIN", tvFechaFin.getText().toString());

                    AlertDialog alertDialog;
                    AlertDialog.Builder AlertDialogBu = new AlertDialog.Builder(getContext());
                    AlertDialogBu.setTitle(R.string.Confirmacion);
                    AlertDialogBu.setMessage(R.string.ConfirmarOperacion);
                    AlertDialogBu.setIcon(android.R.drawable.ic_dialog_alert);
                    AlertDialogBu.setPositiveButton(R.string.Aceptar, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (db.insert("EXPOSICIONES", null, newExposicion) != -1) {
                                Toast.makeText(getActivity(), R.string.tx_añadidoOK, Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(getActivity(), R.string.tx_añadidoERR, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    AlertDialogBu.setNegativeButton(R.string.Cancelar, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(getActivity(), R.string.cancelado, Toast.LENGTH_SHORT).show();
                        }
                    });

                    alertDialog = AlertDialogBu.create();
                    alertDialog.show();


                } else {
                    Toast.makeText(getActivity(), R.string.err_introducir_campos, Toast.LENGTH_SHORT).show();
                }
            }
        });

        btModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tvId.getText().toString().equals("")) {
                    SQLiteOpenHelper bd = new Bd(getContext());
                    final SQLiteDatabase db = bd.getReadableDatabase();
                    db.execSQL("PRAGMA foreign_keys = ON");

                    final ContentValues newExposicion = new ContentValues();
                    newExposicion.put("IDEXPOSICION", tvId.getText().toString());
                    if (!tvNombre.getText().toString().equals("")) {
                        newExposicion.put("NOMBREEXP", tvNombre.getText().toString());
                    }
                    if (!tvDescipcion.getText().toString().equals("")) {
                        newExposicion.put("DESCRIPCION", tvDescipcion.getText().toString());
                    }
                    if (!tvFechaIni.getText().toString().equals("")) {
                        newExposicion.put("FECHAINICIO", tvFechaIni.getText().toString());
                    }
                    if (!tvFechaFin.getText().toString().equals("")) {
                        newExposicion.put("FECHAFIN", tvFechaFin.getText().toString());
                    }

                    AlertDialog alertDialog;
                    AlertDialog.Builder AlertDialogBu = new AlertDialog.Builder(getContext());
                    AlertDialogBu.setTitle(R.string.Confirmacion);
                    AlertDialogBu.setMessage(R.string.ConfirmarOperacion);
                    AlertDialogBu.setIcon(android.R.drawable.ic_dialog_alert);
                    AlertDialogBu.setPositiveButton(R.string.Aceptar, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (db.update("EXPOSICIONES", newExposicion, "IDEXPOSICION = " + tvId.getText().toString(), null) != 0) {
                                Toast.makeText(getActivity(), R.string.tx_modificadoOK, Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(getActivity(), R.string.tx_modificoERR, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    AlertDialogBu.setNegativeButton(R.string.Cancelar, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(getActivity(), R.string.cancelado, Toast.LENGTH_SHORT).show();
                        }
                    });

                    alertDialog = AlertDialogBu.create();
                    alertDialog.show();


                } else {
                    Toast.makeText(getActivity(), R.string.err_introduce_id, Toast.LENGTH_SHORT).show();
                }
            }
        });
        btBorrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!tvId.getText().toString().equals("")) {
                    SQLiteOpenHelper bd = new Bd(getContext());
                    final SQLiteDatabase db = bd.getReadableDatabase();
                    db.execSQL("PRAGMA foreign_keys = ON");

                    AlertDialog alertDialog;
                    AlertDialog.Builder AlertDialogBu = new AlertDialog.Builder(getContext());
                    AlertDialogBu.setTitle(R.string.Confirmacion);
                    AlertDialogBu.setMessage(R.string.ConfirmarOperacion);
                    AlertDialogBu.setIcon(android.R.drawable.ic_dialog_alert);
                    AlertDialogBu.setPositiveButton(R.string.Aceptar, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (db.delete("EXPOSICIONES", "IDEXPOSICION = " + tvId.getText().toString(), null) == 1) {
                                Toast.makeText(getActivity(), R.string.tx_borradoOK, Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(getActivity(), R.string.tx_borradoERR, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    AlertDialogBu.setNegativeButton(R.string.Cancelar, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(getActivity(), R.string.cancelado, Toast.LENGTH_SHORT).show();
                        }
                    });

                    alertDialog = AlertDialogBu.create();
                    alertDialog.show();


                } else {
                    Toast.makeText(getActivity(), R.string.err_introduce_id, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

