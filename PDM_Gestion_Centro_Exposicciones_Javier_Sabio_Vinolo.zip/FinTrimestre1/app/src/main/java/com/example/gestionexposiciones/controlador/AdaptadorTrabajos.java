package com.example.gestionexposiciones.controlador;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gestionexposiciones.R;
import com.example.gestionexposiciones.modelo.Artista;
import com.example.gestionexposiciones.modelo.Trabajo;
import com.example.gestionexposiciones.ui.ArtistasEnDetalle;
import com.example.gestionexposiciones.ui.TrabajosEnDetalle;

import java.util.ArrayList;

public class AdaptadorTrabajos extends RecyclerView.Adapter{

    private ArrayList<Trabajo> listaTrabajos;
    Context contexto;
    public AdaptadorTrabajos(ArrayList<Trabajo> listaTrabajos, Context contexto){
        this.listaTrabajos = listaTrabajos;
        this.contexto = contexto;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View item_trabajo = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_trabajo, parent, false);
        AdaptadorTrabajos.AdaptadorTrabajoViewHolder aavh = new  AdaptadorTrabajos.AdaptadorTrabajoViewHolder(item_trabajo);
        return aavh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Trabajo trab = listaTrabajos.get(position);
        AdaptadorTrabajos.AdaptadorTrabajoViewHolder holderAux = new AdaptadorTrabajos.AdaptadorTrabajoViewHolder(holder.itemView);
        holderAux.txNombre.setText(trab.getNombre());
        holderAux.txDescripcion.setText(trab.getDescripcion());
        holderAux.txDNI.setText(trab.getDNI());
        holderAux.txNombre.setOnClickListener(onClickListener);
    }

    View.OnClickListener onClickListener = (new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            TextView nombreTrab = (TextView)view.findViewById(view.getId());
            int posicion = -1;

            for (int i = 0; i < listaTrabajos.size() ; i++) {
                if (nombreTrab.getText().toString().equals(listaTrabajos.get(i).getNombre())){

                    posicion = i;

                }
            }

            Intent intent = new Intent(contexto, TrabajosEnDetalle.class);
            intent.putExtra("nombreTrabajo", listaTrabajos.get(posicion).getNombre());
            intent.putExtra("descripcion", listaTrabajos.get(posicion).getDescripcion());
            intent.putExtra("tamaño", listaTrabajos.get(posicion).getTamaño());
            intent.putExtra("peso", listaTrabajos.get(posicion).getPeso());
            intent.putExtra("dni", listaTrabajos.get(posicion).getDNI());
            intent.putExtra("foto", listaTrabajos.get(posicion).getFoto());
            contexto.startActivity(intent);

        }
    });


    @Override
    public int getItemCount() {
        return listaTrabajos.size();
    }

    public class AdaptadorTrabajoViewHolder extends RecyclerView.ViewHolder {

        private TextView txNombre;
        private TextView txDescripcion;
        private TextView txDNI;

        public AdaptadorTrabajoViewHolder(@NonNull View itemView) {
            super(itemView);
            txNombre = itemView.findViewById(R.id.txNombreTrab);
            txDescripcion = itemView.findViewById(R.id.txDescripcionTrab);
            txDNI =itemView.findViewById(R.id.txDNITrab);
        }

    }

}
